ESX = exports["es_extended"]:getSharedObject()

local processing = false

RegisterNetEvent('startDrugProcessing')
AddEventHandler('startDrugProcessing', function()
    processing = true
    Citizen.CreateThread(function()
        -- Load the animation dictionary
        RequestAnimDict("mp_arresting")
        while not HasAnimDictLoaded("mp_arresting") do
            Citizen.Wait(100)
        end


        -- Play the un handcuffing animation
        local playerPed = PlayerPedId()
        TaskPlayAnim(playerPed, "mp_arresting", "a_uncuff", 8.0, -8.0, -1, 49, 0, false, false, false)

        exports.rprogress:Start("You are opening a box of candy", 5000)

        while processing do
            Wait(5000)  -- Wait for the animation to play
            processing = false
        end

        -- Clear the animation
        ClearPedTasks(playerPed)
        
        -- Clean up by removing the animation dictionary
        RemoveAnimDict("mp_arresting")
    end)
end)

RegisterNetEvent('stopDrugProcessing')
AddEventHandler('stopDrugProcessing', function()
    local playerPed = PlayerPedId()
    ClearPedTasks(playerPed)  -- Stop the animation when processing is complete
end)
