ESX = exports["es_extended"]:getSharedObject()


ESX.RegisterUsableItem('candybox', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('candybox', 1)

    -- Trigger client event to start processing
    TriggerClientEvent('startDrugProcessing', source)

    -- Simulate processing time (10 seconds)
    Wait(6000)

    -- Add items to the player's inventory
    TriggerClientEvent('ox_lib:notify', source, { title = 'Candy Box', type = 'success', description = 'You have opened a variety pack of candies.', position = 'center-right' })
    xPlayer.addInventoryItem('skittles', 16)
    xPlayer.addInventoryItem('starburst', 16)

    -- Trigger client event to stop processing (optional)
    TriggerClientEvent('stopDrugProcessing', source)
end)

ESX.RegisterUsableItem('chocolatebox', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem('chocolatebox', 1)

    -- Trigger client event to start processing
    TriggerClientEvent('startDrugProcessing', source)

    -- Simulate processing time (10 seconds)
    Wait(6000)

    -- Add items to the player's inventory
    TriggerClientEvent('ox_lib:notify', source, { title = 'Chocolate Box', type = 'success', description = 'You have opened a variety pack of chocolates.', position = 'center-right' })
    xPlayer.addInventoryItem('musketeer', 3)
    xPlayer.addInventoryItem('snickersalmond', 3)
    xPlayer.addInventoryItem('twix', 8)
    xPlayer.addInventoryItem('milkyway', 6)
    xPlayer.addInventoryItem('snickers', 10)

    -- Trigger client event to stop processing (optional)
    TriggerClientEvent('stopDrugProcessing', source)
end)