fx_version 'cerulean'
game 'gta5'

author 'AR Development Edible Script'
description 'AR Development Edible Script By Condumbs'
version '1.0.0'

server_scripts {
    '@es_extended/locale.lua',
    '@mysql-async/lib/MySQL.lua',
    'server/main.lua'
}

client_scripts {
    '@es_extended/locale.lua',
    'client/main.lua'
}

dependencies {
    'es_extended',
    'progressBars',
    'ox_inventory',
    'ox_lib'
}
